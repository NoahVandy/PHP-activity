<html>
<body>
<div align="center">
	<h1>Please select a Calculator Function</h1>
    <a href="{{url('showAdd')}}"><button>Add</button></a><br><br>
    <a href="{{url('showSubtract')}}"><button>Subtract</button></a><br><br>
    <a href="{{url('showMultiply')}}"><button>Multiply</button></a><br><br>
    <a href="{{url('showDivide')}}"><button>Divide</button></a><br><br>
</div>
</body>
</html>