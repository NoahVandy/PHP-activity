<html>
<body>
<div align="center">
	<p>Your result is {{$result}}</p><br><br>
	<a href="{{url('/')}}">Try Again</a>
</div>
</body>
</html>
