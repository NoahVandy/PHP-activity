@extends('layouts.appmaster1')
@section('title', 'ICA Page')

@section('content')
@endsection