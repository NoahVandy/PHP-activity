<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Test</title>
    <link rel="stylesheet" href="resources/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="resources/assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="resources/assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="resources/assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="resources/assets/css/styles.css">
	<title>
		<?php echo $__env->yieldContent('title'); ?>
	</title>
	<body>
		<?php echo $__env->make('layouts.header1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div align="center">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
		<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</body>
</head>
</html>