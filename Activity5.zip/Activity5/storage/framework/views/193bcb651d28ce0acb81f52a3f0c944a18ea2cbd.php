<style>
    .footer
    {
        text-align: center;
        position: absolute;
        bottom: 0;
        width: 100%;
    }
</style>

<div align="center" class="footer">
	<h3>
		Copyright @2020  My Own Work
	</h3>
</div>