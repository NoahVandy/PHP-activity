<?php $__env->startSection('title', 'Login Passed'); ?>

<?php $__env->startSection('content'); ?>
	<?php if($model->getUsername() == 'NoahVandy'): ?>
		<h3>Welcome Noah</h3>
	<?php else: ?>
		<h3>Noah did not login</h3>
	<?php endif; ?>
	<br>
	<a href="<?php echo e(url('login5')); ?>">Login Again</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>