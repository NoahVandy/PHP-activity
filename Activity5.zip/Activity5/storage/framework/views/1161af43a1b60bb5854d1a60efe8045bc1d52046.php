<html>
<body>
<div align="center">
	<p>Your result is <?php echo e($result); ?></p><br><br>
	<a href="<?php echo e(url('/')); ?>">Try Again</a>
</div>
</body>
</html>
