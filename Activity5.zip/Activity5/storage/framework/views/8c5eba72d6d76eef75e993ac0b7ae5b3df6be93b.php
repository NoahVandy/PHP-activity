<div align="center">
    <form action="onSubmitAdd" method = "POST">
        <input type = "hidden" name = "_token"
            value = "<?php echo csrf_token()?>"/>
        <h2>Add View</h2>
        <table>
            <tr>
                <td>Operand #1: </td>
                <td><input type= "text" name= "operand1" maxlength="10"/><?php echo e($errors->first('operand1')); ?></td>
            </tr>
            <tr>
                <td>Operand #2: </td>
                <td><input type= "text" name= "operand2"  maxlength="10"/><?php echo e($errors->first('operand2')); ?></td>
            </tr>
            <tr>
                <td colspan = "2" align = "center">
                    <input type= "submit" value = "Calculate"/>
                </td>
            </tr>
        </table>
    </form>
</div>
    <?php if($errors->count() != 0): ?>
    <h5>List of Errors</h5>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($message); ?> <br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>